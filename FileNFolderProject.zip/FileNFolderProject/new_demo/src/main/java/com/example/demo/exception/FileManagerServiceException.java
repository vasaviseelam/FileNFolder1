package com.example.demo.exception;

public class FileManagerServiceException extends RuntimeException {
    public FileManagerServiceException(String errorMessage) {
        super(errorMessage);
    }
}