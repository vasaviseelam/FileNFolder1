package com.example.demo.config;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@EnableSwagger2
@EnableAutoConfiguration
public class SwaggerConfiguration {

    /**
     * .
     */
    @Bean
    public Docket demoApi() {
        return new Docket(DocumentationType.SWAGGER_2).groupName("demo-api").apiInfo(apiInfo()).select()
                .paths(demoPaths()).build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Demo Api").description("Demo Api")
                .contact(new Contact("dev", "", "nithin@gmail.com")).version("v1").build();
    }

    private Predicate<String> demoPaths() {
        return Predicates.or(regex("/diy-food/.*"));
    }
}