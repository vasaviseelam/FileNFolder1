package com.example.demo.web.rest.resource;


import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GetStatisticsResponseResource {

    Integer folders;

    List<FileType> files;
}

