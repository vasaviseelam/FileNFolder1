package com.example.demo.web.rest.resource;


import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FileDeleteRequestResource {

    @NotNull
    String filePath;

    @NotNull
    String fileName;

}
