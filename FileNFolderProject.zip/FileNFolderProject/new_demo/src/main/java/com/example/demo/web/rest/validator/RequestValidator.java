package com.example.demo.web.rest.validator;

import org.springframework.stereotype.Component;

@Component
public class RequestValidator {
    public void validate() {
    }
}
