package com.example.demo.repository;

import com.example.demo.domain.Folder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FolderRepository extends JpaRepository<Folder, Integer> {

    Folder findByPath(String name);

    void deleteByPath(String folderPath);
}
