package com.example.demo.service;

import com.example.demo.web.rest.resource.*;

public interface FileManagerService {

    void createFile(FileCreateRequestResource fileCreateRequestResource);

    void createFolder(FolderCreateRequestResource folderCreateRequestResource);

    void deleteFile(String filePath, String fileName);

    void deleteFolder(String folderPath);

    GetAllContentsResponseResource getAllContents();

    GetStatisticsResponseResource getStatistics();
}
