package com.example.demo.web.rest.resource;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NestedResource {

    String name;
    String type;
    String extension;
    List<NestedResource> children;
}