package com.example.demo.service.impl;

import com.example.demo.domain.File;
import com.example.demo.domain.Folder;
import com.example.demo.exception.FileManagerServiceException;
import com.example.demo.repository.FileRepository;
import com.example.demo.repository.FolderRepository;
import com.example.demo.service.FileManagerService;
import com.example.demo.web.rest.resource.*;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class FileManagerServiceImpl implements FileManagerService {

    Logger logger = LoggerFactory.getLogger(FileManagerServiceImpl.class);

    @Autowired
    FileRepository fileRepository;

    @Autowired
    FolderRepository folderRepository;

    @Override
    public void createFile(FileCreateRequestResource fileCreateRequestResource) {
        //if path doesn't exist in folder table, throw error
        // else store in files table and type
        if (folderRepository.findByPath(fileCreateRequestResource.getPath()) == null) {
            logger.error("parent folder doesn't exist");
            throw new FileManagerServiceException("parent folder doesn't exist");
        }
        File file = fileRepository.findByName(fileCreateRequestResource.getFileName());
        if (file != null && file.getPath().equals(fileCreateRequestResource.getPath()) && file.getType()
                .equals(fileCreateRequestResource.getFileType())) {
            logger.error("file already exists");
            throw new FileManagerServiceException("file already exists");
        }
        fileRepository.save(
                File.builder().id(UUID.randomUUID().toString()).name(fileCreateRequestResource.getFileName())
                        .type(fileCreateRequestResource.getFileType())
                        .path(fileCreateRequestResource.getPath())
                        .build());
    }

    @Override
    public void createFolder(FolderCreateRequestResource folderCreateRequestResource) {
        //if path doesn't exist in folder table, check if all parent folders exist or else throw error, if all exists create
        //else throw error
        String path = folderCreateRequestResource.getPath();
        String[] subFolders = path.split("/");
        if (!path.equals("/")) {
            subFolders = Arrays.copyOfRange(subFolders, 1, subFolders.length);
        }
        String pathString = "/";
        for (String subFolder : subFolders) {
            if (folderRepository.findByPath(pathString + subFolder) == null) {
                logger.error("parent folder doesn't exist");
                throw new FileManagerServiceException("parent folder doesn't exist");
            }
            pathString += (subFolder + "/");
        }
        if (folderRepository.findByPath((folderCreateRequestResource.getPath().equals("/") ? "" : "/") + "/" +
                folderCreateRequestResource.getFolderName()) != null) {
            logger.error("folder already exist");
            throw new FileManagerServiceException("folder already exist");
        }
        folderRepository.save(
                Folder.builder().id(UUID.randomUUID().toString()).path(folderCreateRequestResource.getPath() +
                        (folderCreateRequestResource.getPath().equals("/") ? "" : "/") +
                        folderCreateRequestResource.getFolderName()).build());
    }

    @Override
    @Transactional
    public void deleteFile(String filePath, String fileName) {
        // if file exists and path also matches folder, then delete
        // or else error
        String name = fileName.split("\\.")[0];
        String fileType = fileName.split("\\.")[1];
        fileRepository.deleteByNameAndPathAndType(name, filePath, fileType);
    }

    @Override
    public void deleteFolder(String folderPath) {
        List<Folder> allFolders = folderRepository.findAll();
        //deleting all folders and sub-folders and files in those.
        List<Folder> foldersToDelete = allFolders.stream().filter(folder -> folder.getPath().startsWith(folderPath))
                .collect(Collectors.toList());
        List<File> allFiles = fileRepository.findAll();
        List<File> filesToDelete = allFiles.stream().filter(file -> file.getPath().startsWith(folderPath))
                .collect(Collectors.toList());
        folderRepository.deleteInBatch(foldersToDelete);
        fileRepository.deleteInBatch(filesToDelete);
    }

    @Override
    public GetAllContentsResponseResource getAllContents() {
        new ArrayList<>(folderRepository.findAll())
                .forEach(e -> System.out.println(e.getPath()));
        System.out.println("--");
        // construct json
        List<File> s = fileRepository.findAll();
        s.forEach(f -> System.out.println(f.getPath() + "/" + f.getName() + "." + f.getType()));

        List<File> allFiles = fileRepository.findAll();

        Map<String, List<File>> pathToFiles = new HashMap<>();

        for (File file : allFiles) {
            pathToFiles.putIfAbsent(file.getPath(), new ArrayList<>());
            pathToFiles.get(file.getPath()).add(file);
        }
        List<NestedResource> files = new ArrayList<>();

        for (String key : pathToFiles.keySet()) {
            NestedResource nestedResource = NestedResource.builder().name(key).type("FOLDER").build();
            List<NestedResource> children = new ArrayList<>();
            for (File file : pathToFiles.get(key)) {
                children.add(
                        NestedResource.builder().type("FILE").extension(file.getType()).name(file.getName()).build());
            }
            nestedResource.setChildren(children);
            files.add(nestedResource);
        }

        return GetAllContentsResponseResource.builder().contents(files).build();
    }

    @Override
    public GetStatisticsResponseResource getStatistics() {
        List<Folder> allFolders = folderRepository.findAll();
        List<File> allFiles = fileRepository.findAll();
        Map<String, Long> typeToCounts = allFiles.stream().map(File::getType).collect(Collectors.toList()).stream()
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

        return GetStatisticsResponseResource.builder().folders(allFolders.size())
                .files(typeToCounts.keySet().stream().map(type -> FileType.builder().type(type)
                        .count(typeToCounts.get(type))
                        .build()).collect(Collectors.toList()))
                .build();
    }
}
