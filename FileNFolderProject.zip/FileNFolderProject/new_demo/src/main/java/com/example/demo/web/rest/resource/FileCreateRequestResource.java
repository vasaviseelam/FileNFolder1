package com.example.demo.web.rest.resource;


import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FileCreateRequestResource {

    @NotNull
    String fileName;

    @NotNull
    String path;

    @NotNull
    String fileType;
}
