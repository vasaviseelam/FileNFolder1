package com.example.demo.web.rest.resource;


import javax.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FolderDeleteRequestResource {

    @NotNull
    String folderPath;

}
