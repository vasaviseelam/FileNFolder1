package com.example.demo.web.rest.assembler;

import org.springframework.stereotype.Component;

@Component
public class RecipeAssembler {
}
