package com.example.demo.repository;

import com.example.demo.domain.File;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface FileRepository extends JpaRepository<File, Integer> {

    File findByName(String name);

    void deleteByNameAndPathAndType(
            @Param("name") String name,
            @Param("path") String path,
            @Param("type") String type);
}
