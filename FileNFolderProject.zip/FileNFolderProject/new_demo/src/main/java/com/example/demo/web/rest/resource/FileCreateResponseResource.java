package com.example.demo.web.rest.resource;


import javax.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class FileCreateResponseResource {

    @NotNull
    String fileName;

    @NotNull
    String path;

    @NotNull
    String fileType;
}
