package com.example.demo.web.rest.controller;

import com.example.demo.service.FileManagerService;
import com.example.demo.web.rest.resource.*;
import com.example.demo.web.rest.validator.RequestValidator;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping({"/file-manager/v1"})
public class FileManagerController {

    @Autowired
    RequestValidator requestValidator;

    @Autowired
    FileManagerService fileManagerService;

    Logger logger = LoggerFactory.getLogger(FileManagerController.class);


    @PostMapping(path = "/file", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Void> createFile(
            @Valid @RequestBody FileCreateRequestResource fileCreateRequestResource) {
        logger.info("Received request to create file");
        fileManagerService.createFile(fileCreateRequestResource);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PostMapping(path = "/folder", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Void> createFolder(
            @Valid @RequestBody FolderCreateRequestResource folderCreateRequestResource) {
        logger.info("Received request to create folder");
        fileManagerService.createFolder(folderCreateRequestResource);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @DeleteMapping(path = "/files", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    // ex: "/a/b/c, file.txt"
    public ResponseEntity<Void> deleteFile(@Valid @RequestBody FileDeleteRequestResource fileDeleteRequestResource) {
        logger.info("Received request to delete file");
        fileManagerService.deleteFile(fileDeleteRequestResource.getFilePath(), fileDeleteRequestResource.getFileName());
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @DeleteMapping(path = "/folders", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<Void> deleteFolder(
            @Valid @RequestBody FolderDeleteRequestResource folderDeleteRequestResource) {
        logger.info("Received request to delete folder");
        fileManagerService.deleteFolder(folderDeleteRequestResource.getFolderPath());
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @GetMapping(value = "/files", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<GetAllContentsResponseResource> getAllContents() {
        logger.info("Received request for fetching all files");
        requestValidator.validate();
        return ResponseEntity.status(HttpStatus.OK).body(fileManagerService.getAllContents());
    }

    @GetMapping(value = "/statistics", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    public ResponseEntity<GetStatisticsResponseResource> getStatistics() {
        logger.info("Received request for fetching all files");
        requestValidator.validate();
        return ResponseEntity.status(HttpStatus.OK).body(fileManagerService.getStatistics());
    }

}
